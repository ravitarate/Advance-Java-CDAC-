import React from 'react'
import "./MyHeader.css"
export default function MyFooter() {
  return (
    <div>
        <h3>&copy;&nbsp;&nbsp;&nbsp; copyrights reserved</h3>
    </div>
  )
}
