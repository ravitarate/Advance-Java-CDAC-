import React from 'react'
import "./MyHeader.css"
export default function MyHeader() {
  return (
    <div>
        <h1>Product Management System</h1>
    </div>
  )
}
