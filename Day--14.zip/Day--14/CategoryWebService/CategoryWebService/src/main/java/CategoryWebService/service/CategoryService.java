package CategoryWebService.service;

import CategoryWebService.model.Category;

public interface CategoryService {

	Category findById(int cid);

}
